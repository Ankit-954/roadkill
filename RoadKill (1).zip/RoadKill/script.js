// consT span = documenT.querySelecTorAll("span");

// span.forEach((span) => {
//   span.addEvenTLisTener("click", () => {
//     span.classList.toggle("orange");
//   });
// });

const T1 = document.getElementById("T1");
const T2 = document.getElementById("T2");
const T3 = document.getElementById("T3");
const T4 = document.getElementById("T4");
const T5 = document.getElementById("T5");
const T6 = document.getElementById("T6");
const T7 = document.getElementById("T7");
const T8 = document.getElementById("T8");
const T9 = document.getElementById("T9");
const T10 = document.getElementById("T10");
const T11 = document.getElementById("T11");
const T12 = document.getElementById("T12");

const D2 = document.getElementById("D2");
const D1 = document.getElementById("D1");
const D3 = document.getElementById("D3");
const D4 = document.getElementById("D4");
const D5 = document.getElementById("D5");
const D6 = document.getElementById("D6");
const D7 = document.getElementById("D7");
const D8 = document.getElementById("D8");
const D9 = document.getElementById("D9");
const D10 = document.getElementById("D10");
const D11 = document.getElementById("D11");
const D12 = document.getElementById("D12");

T1.addEventListener("click", () => {
  T1.classList.toggle("orange");
});

T2.addEventListener("click", () => {
  T2.classList.toggle("orange");
});

T3.addEventListener("click", () => {
  T3.classList.toggle("orange");
});

T4.addEventListener("click", () => {
  T4.classList.toggle("orange");
});

T5.addEventListener("click", () => {
  T5.classList.toggle("orange");
});

T6.addEventListener("click", () => {
  T6.classList.toggle("orange");
});

T7.addEventListener("click", () => {
  T7.classList.toggle("orange");
});

T8.addEventListener("click", () => {
  T8.classList.toggle("orange");
});

T9.addEventListener("click", () => {
  T9.classList.toggle("orange");
});

T10.addEventListener("click", () => {
  T10.classList.toggle("orange");
});

T11.addEventListener("click", () => {
  T11.classList.toggle("orange");
});

T12.addEventListener("click", () => {
  T12.classList.toggle("orange");
});

// Dislike Event

D1.addEventListener("click", () => {
  D1.classList.toggle("Green");
});

D2.addEventListener("click", () => {
  D2.classList.toggle("Green");
});

D3.addEventListener("click", () => {
  D3.classList.toggle("Green");
});

D4.addEventListener("click", () => {
  D4.classList.toggle("Green");
});

D5.addEventListener("click", () => {
  D5.classList.toggle("Green");
});

D6.addEventListener("click", () => {
  D6.classList.toggle("Green");
});

D7.addEventListener("click", () => {
  D7.classList.toggle("Green");
});

D8.addEventListener("click", () => {
  D8.classList.toggle("Green");
});

D9.addEventListener("click", () => {
  D9.classList.toggle("Green");
});

D10.addEventListener("click", () => {
  D10.classList.toggle("Green");
});

D11.addEventListener("click", () => {
  D11.classList.toggle("Green");
});

D12.addEventListener("click", () => {
  D12.classList.toggle("Green");
});
